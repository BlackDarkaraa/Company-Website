<!doctype html>
<html lang="en-GB">
<head>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WLXK2Z');</script>
<!-- End Google Tag Manager -->
<meta name="google-site-verification" content="_aKlKmYDsyihJVlKiMfD5Up4zjouZJrHxywFNr-H8oc" />
<meta name="google-site-verification" content="xXKjuNEbh4a6pX98JzXcCWhgXLz4A96N7_F-bm1Ltsc" />
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon shortcut " type="image/png" sizes="48x48" href="/favicon-48x48.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#e41f2d">
    
    <meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v21.5 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Redscan</title>
	<meta property="og:locale" content="en_GB" />
	<meta property="og:title" content="Page not found - Redscan" />
	<meta property="og:site_name" content="Redscan" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://www.redscan.com/#website","url":"https://www.redscan.com/","name":"Redscan","description":"","publisher":{"@id":"https://www.redscan.com/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://www.redscan.com/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-GB"},{"@type":"Organization","@id":"https://www.redscan.com/#organization","name":"Redscan Ltd.","url":"https://www.redscan.com/","logo":{"@type":"ImageObject","inLanguage":"en-GB","@id":"https://www.redscan.com/#/schema/logo/image/","url":"https://www.redscan.com/media/Redscan-a-Kroll-Company-logo.png","contentUrl":"https://www.redscan.com/media/Redscan-a-Kroll-Company-logo.png","width":350,"height":147,"caption":"Redscan Ltd."},"image":{"@id":"https://www.redscan.com/#/schema/logo/image/"},"sameAs":["https://twitter.com/Redscan","https://www.linkedin.com/company/redscan/"]}]}</script>
	<!-- / Yoast SEO plugin. -->


<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<link rel='stylesheet' id='redscan-style-css' href='https://www.redscan.com/wp-content/themes/redscan/css/site.min.css?ver=1701268536' media='all' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.redscan.com/xmlrpc.php?rsd" />
<script>document.createElement( "picture" );if(!window.HTMLPictureElement && document.addEventListener) {window.addEventListener("DOMContentLoaded", function() {var s = document.createElement("script");s.src = "https://www.redscan.com/wp-content/plugins/webp-express/js/picturefill.min.js";document.body.appendChild(s);});}</script>    <script>
    dataLayer.push({'event' : 'tagAllowed'});
</script>
</head>




<body class="error404 with-top-bar top-bar-active no-hero hfeed no-sidebar">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WLXK2Z"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->


<div class="aws-cookie-consent">
    <div class="aws-cookie-text-wrapper">
        <p class="title">Cookie Notice</p>
        <p class="aws-cookie-text">We use cookies to analyse site traffic and optimise your browsing experience. Accepting necessary cookies is required to provide you with a minimum level of service. <a href="https://www.redscan.com/cookie-statement/" target="_blank">Read Cookie Statement</a></p>
        <button id="aws-cookie-accept">Accept all cookies<span class="rs-icon-wrapper arrow right white"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></button><button id="aws-cookie-agree" class="plain">Use Necessary Cookies Only<span class="rs-icon-wrapper arrow right red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></button>
    </div>
</div><div id="off-canvas" class="off-canvas">
    <div class="main-menu-wrapper">	
    <nav class="mobile-nav">
        <div class="menu-main-menu-new-container"><ul id="primary-menu-mobile" class="menu"><li id="menu-item-11663" class="mega-menu menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-11663 level-0 with-link" data-level="0"><a title="Services" href="https://www.redscan.com/services/" class="depth-0">Services</a><button class="submenu-arrow" title="Expand Menu"></button>
<ul class="sub-menu collapsed">
<li id="menu-item-11671" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-11671 level-1 with-link" data-level="1"><a title="Protect" href="#" class="depth-1">Protect</a><button class="submenu-arrow" title="Expand Menu"></button>
	<ul>
<li id="menu-item-11753" class="mega-title menu-item menu-item-type-custom menu-item-object-custom menu-item-11753 level-2" data-level="2"><span class="mega-menu-title">Offensive Security</span></li>
<li id="menu-item-11672" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11672 level-2 with-link" data-level="2"><a title="Penetration Testing" href="https://www.redscan.com/services/penetration-testing/" class="depth-2">Penetration Testing</a></li>
<li id="menu-item-11673" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11673 level-2 with-link" data-level="2"><a title="Web Application Testing" href="https://www.redscan.com/services/penetration-testing/web-application-testing/" class="depth-2">Web Application Testing</a></li>
<li id="menu-item-11755" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11755 level-2 with-link" data-level="2"><a title="Cloud Penetration Testing" href="https://www.redscan.com/services/penetration-testing/cloud-penetration-testing/" class="depth-2">Cloud Penetration Testing</a></li>
<li id="menu-item-12992" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12992 level-2 with-link" data-level="2"><a title="Agile Penetration Testing" href="https://www.redscan.com/services/penetration-testing/agile-penetration-testing/" class="depth-2">Agile Penetration Testing</a></li>
<li id="menu-item-11796" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11796 level-2 with-link" data-level="2"><a title="Red Teaming" href="https://www.redscan.com/services/red-team-operations/" class="depth-2">Red Teaming</a></li>
<li id="menu-item-11754" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11754 level-2 with-link" data-level="2"><a title="Breach and Attack Simulation" href="https://www.redscan.com/services/breach-and-attack-simulation/" class="depth-2">Breach and Attack Simulation</a></li>
<li id="menu-item-11756" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11756 level-2 with-link" data-level="2"><a title="Vulnerability Assessment" href="https://www.redscan.com/services/vulnerability-assessment/" class="depth-2">Vulnerability Assessment</a></li>
<li id="menu-item-11772" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11772 level-2 with-link" data-level="2"><a title="Ransomware Preparedness" href="https://www.redscan.com/services/ransomware-preparedness-assessment/" class="depth-2">Ransomware Preparedness</a></li>
<li id="menu-item-11676" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11676 level-2 with-link" data-level="2"><a title="Scenario-Based Testing" href="https://www.redscan.com/services/scenario-based-testing/" class="depth-2">Scenario-Based Testing</a></li>
<li id="menu-item-11758" class="mega-title menu-item menu-item-type-custom menu-item-object-custom menu-item-11758 level-2" data-level="2"><span class="mega-menu-title">Advisory Services</span></li>
<li id="menu-item-11759" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11759 level-2 with-link" data-level="2"><a title="Cyber Policy Review" href="https://www.redscan.com/services/cyber-policy-review/" class="depth-2">Cyber Policy Review</a></li>
<li id="menu-item-11760" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11760 level-2 with-link" data-level="2"><a title="Cyber Due Diligence" href="https://www.redscan.com/services/cyber-security-due-diligence/" class="depth-2">Cyber Due Diligence</a></li>
<li id="menu-item-11761" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11761 level-2 with-link" data-level="2"><a title="Supply Chain Due Diligence" href="https://www.redscan.com/services/supply-chain-due-diligence/" class="depth-2">Supply Chain Due Diligence</a></li>
<li id="menu-item-11762" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11762 level-2 with-link" data-level="2"><a title="Compliance Advisory" href="https://www.redscan.com/services/comply/" class="depth-2">Compliance Advisory</a></li>
<li id="menu-item-11763" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11763 level-2 with-link" data-level="2"><a title="Virtual CISO" href="https://www.redscan.com/services/virtual-ciso/" class="depth-2">Virtual CISO</a></li>
<li id="menu-item-11764" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11764 level-2 with-link" data-level="2"><a title="DPO Services" href="https://www.redscan.com/services/dpo-services/" class="depth-2">DPO Services</a></li>
<li id="menu-item-11687" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11687 level-2 with-link" data-level="2"><a title="Dark Web Monitoring" href="https://www.redscan.com/services/dark-web-monitoring/" class="depth-2">Dark Web Monitoring</a></li>
<li id="menu-item-13153" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13153 level-2 with-link" data-level="2"><a title="Application Security" href="https://www.redscan.com/services/application-security-services/" class="depth-2">Application Security</a></li>
<li id="menu-item-13263" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13263 level-2 with-link" data-level="2"><a title="Threat Modelling" href="https://www.redscan.com/services/threat-modelling/" class="depth-2">Threat Modelling</a></li>
	</ul>
</li>
<li id="menu-item-11664" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-11664 level-1 with-link" data-level="1"><a title="Detect" href="#" class="depth-1">Detect</a><button class="submenu-arrow" title="Expand Menu"></button>
	<ul>
<li id="menu-item-11665" class="mega-title menu-item menu-item-type-custom menu-item-object-custom menu-item-11665 level-2 with-link" data-level="2"><a title="Managed Detection and Response" rel="4977" href="/services/managed-detection-and-response/" class="depth-2">Managed Detection and Response</a></li>
<li id="menu-item-12577" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12577 level-2 with-link" data-level="2"><a title="Kroll Responder MDR" href="https://www.redscan.com/services/managed-detection-and-response/" class="depth-2">Kroll Responder MDR</a></li>
<li id="menu-item-12958" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12958 level-2 with-link" data-level="2"><a title="MDR for Microsoft" href="https://www.redscan.com/services/managed-detection-and-response/microsoft/" class="depth-2">MDR for Microsoft</a></li>
<li id="menu-item-11667" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11667 level-2 with-link" data-level="2"><a title="Use Cases" href="https://www.redscan.com/services/managed-detection-and-response/use-cases/" class="depth-2">Use Cases</a></li>
<li id="menu-item-11668" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11668 level-2 with-link" data-level="2"><a title="Redscan Platform" href="https://www.redscan.com/services/managed-detection-and-response/the-redscan-platform/" class="depth-2">Redscan Platform</a></li>
<li id="menu-item-11669" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11669 level-2 with-link" data-level="2"><a title="Features Table" href="https://www.redscan.com/services/managed-detection-and-response/mdr-features/" class="depth-2">Features Table</a></li>
<li id="menu-item-11670" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11670 level-2 with-link" data-level="2"><a title="MDR vs MSSP" href="https://www.redscan.com/services/managed-detection-and-response/mdr-vs-mssp/" class="depth-2">MDR vs MSSP</a></li>
	</ul>
</li>
<li id="menu-item-11779" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-11779 level-1 with-link" data-level="1"><a title="Respond" href="#" class="depth-1">Respond</a><button class="submenu-arrow" title="Expand Menu"></button>
	<ul>
<li id="menu-item-11766" class="mega-title menu-item menu-item-type-custom menu-item-object-custom menu-item-11766 level-2" data-level="2"><span class="mega-menu-title">Digital Forensics and Incident Response</span></li>
<li id="menu-item-11767" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11767 level-2 with-link" data-level="2"><a title="Cyber Incident Response" href="https://www.redscan.com/services/cyber-incident-response/" class="depth-2">Cyber Incident Response</a></li>
<li id="menu-item-11768" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11768 level-2 with-link" data-level="2"><a title="Incident Response Planning" href="https://www.redscan.com/services/cyber-incident-response-planning/" class="depth-2">Incident Response Planning</a></li>
<li id="menu-item-11769" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11769 level-2 with-link" data-level="2"><a title="Breach Notification" href="https://www.redscan.com/services/breach-notification/" class="depth-2">Breach Notification</a></li>
<li id="menu-item-11770" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11770 level-2 with-link" data-level="2"><a title="Digital Forensics" href="https://www.redscan.com/services/cyber-security-digital-forensics/" class="depth-2">Digital Forensics</a></li>
<li id="menu-item-11771" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11771 level-2 with-link" data-level="2"><a title="Litigation Support" href="https://www.redscan.com/services/cyber-litigation-support/" class="depth-2">Litigation Support</a></li>
<li id="menu-item-11757" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11757 level-2 with-link" data-level="2"><a title="Malware Analysis &amp;&lt;br /&gt;Reverse Engineering" href="https://www.redscan.com/services/malware-analysis-and-reverse-engineering/" class="depth-2">Malware Analysis &#038;<br />Reverse Engineering</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-11688" class="mega-menu menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-11688 level-0 with-link" data-level="0"><a title="Solutions" href="https://www.redscan.com/solutions/" class="depth-0">Solutions</a><button class="submenu-arrow" title="Expand Menu"></button>
<ul class="sub-menu collapsed">
<li id="menu-item-11689" class="two-column menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-11689 level-1 with-link" data-level="1"><a title="Industry" href="/industries/" class="depth-1">Industry</a><button class="submenu-arrow" title="Expand Menu"></button>
	<ul>
<li id="menu-item-11690" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11690 level-2 with-link" data-level="2"><a title="Education" href="https://www.redscan.com/industries/education/" class="depth-2">Education</a></li>
<li id="menu-item-11691" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11691 level-2 with-link" data-level="2"><a title="Energy" href="https://www.redscan.com/industries/energy/" class="depth-2">Energy</a></li>
<li id="menu-item-11692" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11692 level-2 with-link" data-level="2"><a title="Finance" href="https://www.redscan.com/industries/finance/" class="depth-2">Finance</a></li>
<li id="menu-item-11693" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11693 level-2 with-link" data-level="2"><a title="Fintech" href="https://www.redscan.com/industries/fintech/" class="depth-2">Fintech</a></li>
<li id="menu-item-11694" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11694 level-2 with-link" data-level="2"><a title="Government" href="https://www.redscan.com/industries/government/" class="depth-2">Government</a></li>
<li id="menu-item-11695" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11695 level-2 with-link" data-level="2"><a title="Healthcare" href="https://www.redscan.com/industries/healthcare/" class="depth-2">Healthcare</a></li>
<li id="menu-item-11696" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11696 level-2 with-link" data-level="2"><a title="Legal" href="https://www.redscan.com/industries/legal/" class="depth-2">Legal</a></li>
<li id="menu-item-11697" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11697 level-2 with-link" data-level="2"><a title="Manufacturing" href="https://www.redscan.com/industries/manufacturing/" class="depth-2">Manufacturing</a></li>
<li id="menu-item-11698" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11698 level-2 with-link" data-level="2"><a title="Media" href="https://www.redscan.com/industries/media/" class="depth-2">Media</a></li>
<li id="menu-item-11699" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11699 level-2 with-link" data-level="2"><a title="Nonprofit" href="https://www.redscan.com/industries/nonprofit/" class="depth-2">Nonprofit</a></li>
<li id="menu-item-11700" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11700 level-2 with-link" data-level="2"><a title="Property" href="https://www.redscan.com/industries/property/" class="depth-2">Property</a></li>
<li id="menu-item-11701" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11701 level-2 with-link" data-level="2"><a title="Retail" href="https://www.redscan.com/industries/retail-and-ecommerce/" class="depth-2">Retail</a></li>
<li id="menu-item-11702" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11702 level-2 with-link" data-level="2"><a title="Technology" href="https://www.redscan.com/industries/technology/" class="depth-2">Technology</a></li>
<li id="menu-item-11703" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11703 level-2 with-link" data-level="2"><a title="Transport" href="https://www.redscan.com/industries/transport/" class="depth-2">Transport</a></li>
	</ul>
</li>
<li id="menu-item-11704" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-11704 level-1 with-link" data-level="1"><a title="Compliance" href="/services/comply/" class="depth-1">Compliance</a><button class="submenu-arrow" title="Expand Menu"></button>
	<ul>
<li id="menu-item-11705" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11705 level-2 with-link" data-level="2"><a title="GDPR" href="https://www.redscan.com/services/gdpr/" class="depth-2">GDPR</a></li>
<li id="menu-item-11706" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11706 level-2 with-link" data-level="2"><a title="DPA 2018" href="https://www.redscan.com/services/data-protection-act-2018/" class="depth-2">DPA 2018</a></li>
<li id="menu-item-11707" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11707 level-2 with-link" data-level="2"><a title="PCI DSS" href="https://www.redscan.com/services/pci-dss/" class="depth-2">PCI DSS</a></li>
<li id="menu-item-11708" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11708 level-2 with-link" data-level="2"><a title="ISO 27001" href="https://www.redscan.com/services/iso-27001/" class="depth-2">ISO 27001</a></li>
<li id="menu-item-11709" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11709 level-2 with-link" data-level="2"><a title="NIS Directive" href="https://www.redscan.com/services/nis-directive-and-nis-regulations/" class="depth-2">NIS Directive</a></li>
<li id="menu-item-11710" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11710 level-2 with-link" data-level="2"><a title="SWIFT CSP" href="https://www.redscan.com/services/swift-customer-security-programme/" class="depth-2">SWIFT CSP</a></li>
<li id="menu-item-11711" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11711 level-2 with-link" data-level="2"><a title="NHS DSP Toolkit" href="https://www.redscan.com/services/nhs-data-security-and-protection-toolkit/" class="depth-2">NHS DSP Toolkit</a></li>
	</ul>
</li>
<li id="menu-item-11712" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-11712 level-1 with-link" data-level="1"><a title="Cloud Security" href="/services/cloud-security-management-and-monitoring/" class="depth-1">Cloud Security</a><button class="submenu-arrow" title="Expand Menu"></button>
	<ul>
<li id="menu-item-11713" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11713 level-2 with-link" data-level="2"><a title="Hybrid Cloud" href="https://www.redscan.com/services/cloud-security-management-and-monitoring/hybrid/" class="depth-2">Hybrid Cloud</a></li>
<li id="menu-item-11714" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11714 level-2 with-link" data-level="2"><a title="AWS" href="https://www.redscan.com/services/cloud-security-management-and-monitoring/aws/" class="depth-2">AWS</a></li>
<li id="menu-item-11715" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11715 level-2 with-link" data-level="2"><a title="Azure" href="https://www.redscan.com/services/cloud-security-management-and-monitoring/azure/" class="depth-2">Azure</a></li>
<li id="menu-item-11716" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11716 level-2 with-link" data-level="2"><a title="GCP" href="https://www.redscan.com/services/cloud-security-management-and-monitoring/gcp-security-monitoring/" class="depth-2">GCP</a></li>
<li id="menu-item-11717" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11717 level-2 with-link" data-level="2"><a title="Office 365" href="https://www.redscan.com/services/cloud-security-management-and-monitoring/office-365/" class="depth-2">Office 365</a></li>
<li id="menu-item-11718" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11718 level-2 with-link" data-level="2"><a title="G Suite" href="https://www.redscan.com/services/cloud-security-management-and-monitoring/g-suite/" class="depth-2">G Suite</a></li>
<li id="menu-item-11719" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11719 level-2 with-link" data-level="2"><a title="Hyper-V" href="https://www.redscan.com/services/cloud-security-management-and-monitoring/hyper-v/" class="depth-2">Hyper-V</a></li>
<li id="menu-item-11720" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11720 level-2 with-link" data-level="2"><a title="VMWare" href="https://www.redscan.com/services/cloud-security-management-and-monitoring/vmware/" class="depth-2">VMWare</a></li>
	</ul>
</li>
<li id="menu-item-11721" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-11721 level-1 with-link" data-level="1"><a title="Security Challenge" href="/solutions/challenges/" class="depth-1">Security Challenge</a><button class="submenu-arrow" title="Expand Menu"></button>
	<ul>
<li id="menu-item-11722" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11722 level-2 with-link" data-level="2"><a title="Mitigating cyber security risk" href="https://www.redscan.com/solutions/mitigating-cyber-security-risk/" class="depth-2">Mitigating cyber security risk</a></li>
<li id="menu-item-11723" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11723 level-2 with-link" data-level="2"><a title="Identifying and responding to threats" href="https://www.redscan.com/solutions/identifying-and-responding-to-threats/" class="depth-2">Identifying and responding to threats</a></li>
<li id="menu-item-11724" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11724 level-2 with-link" data-level="2"><a title="Testing cyber security readiness" href="https://www.redscan.com/solutions/testing-cyber-security-readiness/" class="depth-2">Testing cyber security readiness</a></li>
<li id="menu-item-11725" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11725 level-2 with-link" data-level="2"><a title="Managing cloud security" href="https://www.redscan.com/services/cloud-security-management-and-monitoring/" class="depth-2">Managing cloud security</a></li>
<li id="menu-item-11726" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11726 level-2 with-link" data-level="2"><a title="Investigating and reporting breaches" href="https://www.redscan.com/solutions/investigating-and-reporting-data-breaches/" class="depth-2">Investigating and reporting breaches</a></li>
<li id="menu-item-11727" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11727 level-2 with-link" data-level="2"><a title="Protecting against malware" href="https://www.redscan.com/solutions/protecting-against-malware/" class="depth-2">Protecting against malware</a></li>
<li id="menu-item-11728" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11728 level-2 with-link" data-level="2"><a title="Tackling phishing and BEC attacks" href="https://www.redscan.com/solutions/preventing-phishing-bec-attacks/" class="depth-2">Tackling phishing and BEC attacks</a></li>
<li id="menu-item-11729" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11729 level-2 with-link" data-level="2"><a title="Defending against insider threats" href="https://www.redscan.com/solutions/insider-threats-cyber-security/" class="depth-2">Defending against insider threats</a></li>
<li id="menu-item-11730" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11730 level-2 with-link" data-level="2"><a title="Achieving GDPR compliance" href="https://www.redscan.com/services/gdpr/" class="depth-2">Achieving GDPR compliance</a></li>
<li id="menu-item-11731" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11731 level-2 with-link" data-level="2"><a title="Securing remote workers" href="https://www.redscan.com/solutions/securing-remote-workers/" class="depth-2">Securing remote workers</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-11732" class="mega-menu menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-11732 level-0 with-link" data-level="0"><a title="Company" href="https://www.redscan.com/company/" class="depth-0">Company</a><button class="submenu-arrow" title="Expand Menu"></button>
<ul class="sub-menu collapsed">
<li id="menu-item-11733" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-11733 level-1 with-link" data-level="1"><a title="About" href="/company/" class="depth-1">About</a><button class="submenu-arrow" title="Expand Menu"></button>
	<ul>
<li id="menu-item-11734" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11734 level-2 with-link" data-level="2"><a title="Company Overview" href="https://www.redscan.com/company/" class="depth-2">Company Overview</a></li>
<li id="menu-item-11736" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11736 level-2 with-link" data-level="2"><a title="Careers" href="https://www.redscan.com/company/careers/" class="depth-2">Careers</a></li>
<li id="menu-item-11737" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11737 level-2 with-link" data-level="2"><a title="Awards" href="https://www.redscan.com/company/awards-and-recognition/" class="depth-2">Awards</a></li>
<li id="menu-item-11738" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11738 level-2 with-link" data-level="2"><a title="Accreditations" href="https://www.redscan.com/company/accreditations-and-memberships/" class="depth-2">Accreditations</a></li>
<li id="menu-item-11739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11739 level-2 with-link" data-level="2"><a title="Redscan Labs" href="https://www.redscan.com/company/redscan-labs/" class="depth-2">Redscan Labs</a></li>
	</ul>
</li>
<li id="menu-item-11740" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-11740 level-1 with-link" data-level="1"><a title="Resources" href="/resources/" class="depth-1">Resources</a><button class="submenu-arrow" title="Expand Menu"></button>
	<ul>
<li id="menu-item-11741" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-11741 level-2 with-link" data-level="2"><a title="Cyber Security Blog" href="https://www.redscan.com/news/" class="depth-2">Cyber Security Blog</a></li>
<li id="menu-item-11742" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11742 level-2 with-link" data-level="2"><a title="Case Studies" href="https://www.redscan.com/company/case-studies/" class="depth-2">Case Studies</a></li>
<li id="menu-item-11743" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11743 level-2 with-link" data-level="2"><a title="Resource Hub" href="https://www.redscan.com/resources/" class="depth-2">Resource Hub</a></li>
<li id="menu-item-11744" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11744 level-2 with-link" data-level="2"><a title="Press Releases" href="https://www.redscan.com/press-releases/" class="depth-2">Press Releases</a></li>
<li id="menu-item-11745" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11745 level-2 with-link" data-level="2"><a title="Media Coverage" href="https://www.redscan.com/media-coverage/" class="depth-2">Media Coverage</a></li>
<li id="menu-item-11746" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11746 level-2 with-link" data-level="2"><a title="Cyber Security Glossary" href="https://www.redscan.com/cyber-security-glossary/" class="depth-2">Cyber Security Glossary</a></li>
	</ul>
</li>
<li id="menu-item-11748" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-11748 level-1 with-link" data-level="1"><a title="Contact Us" href="/general-enquiries/" class="depth-1">Contact Us</a><button class="submenu-arrow" title="Expand Menu"></button>
	<ul>
<li id="menu-item-11749" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11749 level-2 with-link" data-level="2"><a title="General Enquiries" href="https://www.redscan.com/general-enquiries/" class="depth-2">General Enquiries</a></li>
<li id="menu-item-12489" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12489 level-2 with-link" data-level="2"><a title="Incident Response Enquiries" href="https://www.redscan.com/incident-response-enquiries/" class="depth-2">Incident Response Enquiries</a></li>
<li id="menu-item-11750" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11750 level-2 with-link" data-level="2"><a title="Customer Support" href="https://www.redscan.com/general-enquiries/customer-support/" class="depth-2">Customer Support</a></li>
<li id="menu-item-11751" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11751 level-2 with-link" data-level="2"><a title="Partner With Us" href="https://www.redscan.com/partners/" class="depth-2">Partner With Us</a></li>
<li id="menu-item-11752" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11752 level-2 with-link" data-level="2"><a title="Media Requests" href="https://www.redscan.com/media-requests/" class="depth-2">Media Requests</a></li>
	</ul>
</li>
</ul>
</li>
</ul></div>			
    </nav>
    <div class="mobile-cta">
        <a href="/general-enquiries/" class="button">Get In Touch <span class="rs-icon-wrapper arrow right"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></a>
    </div>
</div></div>

<div id="art-side-form" class="art-side-form" data-closed="1">
    <div class="close-side" data-toggle="#art-side-form"> <span class="cross"></span></div>
    <div id="art-side-form-tab" class="art-side-form-tab">
        <div class="art-side-form-side-text">Contact Us</div>
        <div class="art-side-form-side-icon"><span class="rs-icon-wrapper blog white"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#blog"></use></svg></span></div>
    </div>
    <div class="art-side-form-inner">
        <p class="h3-title">Contact Us</p>
        <p>Please get in touch using the form below</p>
                            
<div class="respond form-wrapper">
    <form id="fxoifim" class="form-1 contact-form" action="https://www.redscan.com/news/q3-2023-threat-landscape-report/" method="post">

    <div class="input-wrapper half first">
    <input type="text" aria-label="First name" required aria-required="true" name="first_name" placeholder="First name *" value="" maxlength="30">
    <div class="form-error"></div>
</div>
<div class="input-wrapper half">
    <input type="text" aria-label="Last name" required aria-required="true" name="last_name" placeholder="Last name *" value="" maxlength="30">
    <div class="form-error"></div>
</div>
<div class="input-wrapper full">
    <input type="email" aria-label="Your email" required aria-required="true" name="email_address" placeholder="Business email address *" value=""  maxlength="40">
    <div class="form-error"></div>
</div>
<div class="input-wrapper half first">    
    <input type="tel" aria-label="Your phone number" required aria-required="true" name="phone_number" placeholder="Phone number *" value="" maxlength="20">
    <div class="form-error"></div>
</div>
<div class="input-wrapper half">
    <input type="text" aria-label="Company" required aria-required="true" name="company" placeholder="Company *" value="" class="full"  maxlength="40">
    <div class="form-error"></div>
</div>
<input type="text" name="maps_certopt" value="" class="maps_certopt" autocomplete="off">

<input type="hidden" name="validate_form" value="f6d0c49036">
    <div class="input-wrapper full">
        <div class="select-wrapper">
    <select name="country" required>
        <option value="">-- Select Country -- *
        </option>
        <option value="Aland Islands">Aland Islands
        </option>
        <option value="Afghanistan">Afghanistan
        </option>
        <option value="Albania">Albania
        </option>
        <option value="Algeria">Algeria
        </option>
        <option value="Andorra">Andorra
        </option>
        <option value="Angola">Angola
        </option>
        <option value="Anguilla">Anguilla
        </option>
        <option value="Antarctica">Antarctica
        </option>
        <option value="Antigua and Barbuda">Antigua and Barbuda
        </option>
        <option value="Argentina">Argentina
        </option>
        <option value="Armenia">Armenia
        </option>
        <option value="Aruba">Aruba
        </option>
        <option value="Australia">Australia
        </option>
        <option value="Austria">Austria
        </option>
        <option value="Azerbaijan">Azerbaijan
        </option>
        <option value="Bahamas">Bahamas
        </option>
        <option value="Bahrain">Bahrain
        </option>
        <option value="Bangladesh">Bangladesh
        </option>
        <option value="Barbados">Barbados
        </option>
        <option value="Belarus">Belarus
        </option>
        <option value="Belgium">Belgium
        </option>
        <option value="Belize">Belize
        </option>
        <option value="Benin">Benin
        </option>
        <option value="Bermuda">Bermuda
        </option>
        <option value="Bhutan">Bhutan
        </option>
        <option value="Bolivia, Plurinational State of">Bolivia, Plurinational State of
        </option>
        <option value="Bonaire, Sint Eustatius and Saba">Bonaire, Sint Eustatius and Saba
        </option>
        <option value="Bosnia and Herzegovina">Bosnia and Herzegovina
        </option>
        <option value="Botswana">Botswana
        </option>
        <option value="Bouvet Island">Bouvet Island
        </option>
        <option value="Brazil">Brazil
        </option>
        <option value="British Indian Ocean Territory">British Indian Ocean Territory
        </option>
        <option value="Brunei Darussalam">Brunei Darussalam
        </option>
        <option value="Bulgaria">Bulgaria
        </option>
        <option value="Burkina Faso">Burkina Faso
        </option>
        <option value="Burundi">Burundi
        </option>
        <option value="Cambodia">Cambodia
        </option>
        <option value="Cameroon">Cameroon
        </option>
        <option value="Canada">Canada
        </option>
        <option value="Cape Verde">Cape Verde
        </option>
        <option value="Cayman Islands">Cayman Islands
        </option>
        <option value="Central African Republic">Central African Republic
        </option>
        <option value="Chad">Chad
        </option>
        <option value="Chile">Chile
        </option>
        <option value="China">China
        </option>
        <option value="Christmas Island">Christmas Island
        </option>
        <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands
        </option>
        <option value="Colombia">Colombia
        </option>
        <option value="Comoros">Comoros
        </option>
        <option value="Congo">Congo
        </option>
        <option value="Congo, the Democratic Republic of the">Congo, the Democratic Republic of the
        </option>
        <option value="Cook Islands">Cook Islands
        </option>
        <option value="Costa Rica">Costa Rica
        </option>
        <option value="Cote d'Ivoire">Cote d'Ivoire
        </option>
        <option value="Croatia">Croatia
        </option>
        <option value="Cuba">Cuba
        </option>
        <option value="Curaçao">Curaçao
        </option>
        <option value="Cyprus">Cyprus
        </option>
        <option value="Czech Republic">Czech Republic
        </option>
        <option value="Denmark">Denmark
        </option>
        <option value="Djibouti">Djibouti
        </option>
        <option value="Dominica">Dominica
        </option>
        <option value="Dominican Republic">Dominican Republic
        </option>
        <option value="Ecuador">Ecuador
        </option>
        <option value="Egypt">Egypt
        </option>
        <option value="El Salvador">El Salvador
        </option>
        <option value="Equatorial Guinea">Equatorial Guinea
        </option>
        <option value="Eritrea">Eritrea
        </option>
        <option value="Estonia">Estonia
        </option>
        <option value="Ethiopia">Ethiopia
        </option>
        <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)
        </option>
        <option value="Faroe Islands">Faroe Islands
        </option>
        <option value="Fiji">Fiji
        </option>
        <option value="Finland">Finland
        </option>
        <option value="France">France
        </option>
        <option value="French Guiana">French Guiana
        </option>
        <option value="French Polynesia">French Polynesia
        </option>
        <option value="French Southern Territories">French Southern Territories
        </option>
        <option value="Gabon">Gabon
        </option>
        <option value="Gambia">Gambia
        </option>
        <option value="Georgia">Georgia
        </option>
        <option value="Germany">Germany
        </option>
        <option value="Ghana">Ghana
        </option>
        <option value="Gibraltar">Gibraltar
        </option>
        <option value="Greece">Greece
        </option>
        <option value="Greenland">Greenland
        </option>
        <option value="Grenada">Grenada
        </option>
        <option value="Guadeloupe">Guadeloupe
        </option>
        <option value="Guam">Guam
        </option>
        <option value="Guatemala">Guatemala
        </option>
        <option value="Guernsey">Guernsey
        </option>
        <option value="Guinea">Guinea
        </option>
        <option value="Guinea-Bissau">Guinea-Bissau
        </option>
        <option value="Guyana">Guyana
        </option>
        <option value="Haiti">Haiti
        </option>
        <option value="Heard Island and McDonald Islands">Heard Island and McDonald Islands
        </option>
        <option value="Holy See (Vatican City State)">Holy See (Vatican City State)
        </option>
        <option value="Honduras">Honduras
        </option>
        <option value="Hong Kong">Hong Kong
        </option>
        <option value="Hungary">Hungary
        </option>
        <option value="Iceland">Iceland
        </option>
        <option value="India">India
        </option>
        <option value="Indonesia">Indonesia
        </option>
        <option value="Iran, Islamic Republic of">Iran, Islamic Republic of
        </option>
        <option value="Iraq">Iraq
        </option>
        <option value="Ireland">Ireland
        </option>
        <option value="Isle of Man">Isle of Man
        </option>
        <option value="Israel">Israel
        </option>
        <option value="Italy">Italy
        </option>
        <option value="Jamaica">Jamaica
        </option>
        <option value="Japan">Japan
        </option>
        <option value="Jersey">Jersey
        </option>
        <option value="Jordan">Jordan
        </option>
        <option value="Kazakhstan">Kazakhstan
        </option>
        <option value="Kenya">Kenya
        </option>
        <option value="Kiribati">Kiribati
        </option>
        <option value="Kuwait">Kuwait
        </option>
        <option value="Kyrgyzstan">Kyrgyzstan
        </option>
        <option value="Lao People's Democratic Republic">Lao People's Democratic Republic
        </option>
        <option value="Latvia">Latvia
        </option>
        <option value="Lebanon">Lebanon
        </option>
        <option value="Lesotho">Lesotho
        </option>
        <option value="Liberia">Liberia
        </option>
        <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya
        </option>
        <option value="Liechtenstein">Liechtenstein
        </option>
        <option value="Lithuania">Lithuania
        </option>
        <option value="Luxembourg">Luxembourg
        </option>
        <option value="Macao">Macao
        </option>
        <option value="Macedonia, the former Yugoslav Republic of">Macedonia, the former Yugoslav Republic of
        </option>
        <option value="Madagascar">Madagascar
        </option>
        <option value="Malawi">Malawi
        </option>
        <option value="Malaysia">Malaysia
        </option>
        <option value="Maldives">Maldives
        </option>
        <option value="Mali">Mali
        </option>
        <option value="Malta">Malta
        </option>
        <option value="Marshall Islands">Marshall Islands
        </option>
        <option value="Martinique">Martinique
        </option>
        <option value="Mauritania">Mauritania
        </option>
        <option value="Mauritius">Mauritius
        </option>
        <option value="Mayotte">Mayotte
        </option>
        <option value="Mexico">Mexico
        </option>
        <option value="Moldova, Republic of">Moldova, Republic of
        </option>
        <option value="Monaco">Monaco
        </option>
        <option value="Mongolia">Mongolia
        </option>
        <option value="Montenegro">Montenegro
        </option>
        <option value="Montserrat">Montserrat
        </option>
        <option value="Morocco">Morocco
        </option>
        <option value="Mozambique">Mozambique
        </option>
        <option value="Myanmar">Myanmar
        </option>
        <option value="Namibia">Namibia
        </option>
        <option value="Nauru">Nauru
        </option>
        <option value="Nepal">Nepal
        </option>
        <option value="Netherlands">Netherlands
        </option>
        <option value="Netherlands Antilles">Netherlands Antilles
        </option>
        <option value="New Caledonia">New Caledonia
        </option>
        <option value="New Zealand">New Zealand
        </option>
        <option value="Nicaragua">Nicaragua
        </option>
        <option value="Niger">Niger
        </option>
        <option value="Nigeria">Nigeria
        </option>
        <option value="Niue">Niue
        </option>
        <option value="Norfolk Island">Norfolk Island
        </option>
        <option value="North Korea">North Korea
        </option>
        <option value="Northern Mariana Islands">Northern Mariana Islands
        </option>
        <option value="Norway">Norway
        </option>
        <option value="Oman">Oman
        </option>
        <option value="Pakistan">Pakistan
        </option>
        <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied
        </option>
        <option value="Panama">Panama
        </option>
        <option value="Papua New Guinea">Papua New Guinea
        </option>
        <option value="Paraguay">Paraguay
        </option>
        <option value="Peru">Peru
        </option>
        <option value="Philippines">Philippines
        </option>
        <option value="Pitcairn">Pitcairn
        </option>
        <option value="Poland">Poland
        </option>
        <option value="Portugal">Portugal
        </option>
        <option value="Puerto Rico">Puerto Rico
        </option>
        <option value="Qatar">Qatar
        </option>
        <option value="Reunion">Reunion
        </option>
        <option value="Romania">Romania
        </option>
        <option value="Russian Federation">Russian Federation
        </option>
        <option value="Rwanda">Rwanda
        </option>
        <option value="Saint Barthélemy">Saint Barthélemy
        </option>
        <option value="Saint Helena, Ascension and Tristan da Cunha">Saint Helena, Ascension and Tristan da Cunha
        </option>
        <option value="Saint Kitts and Nevis">Saint Kitts and Nevis
        </option>
        <option value="Saint Lucia">Saint Lucia
        </option>
        <option value="Saint Martin (French part)">Saint Martin (French part)
        </option>
        <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon
        </option>
        <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines
        </option>
        <option value="Samoa">Samoa
        </option>
        <option value="San Marino">San Marino
        </option>
        <option value="Sao Tome and Principe">Sao Tome and Principe
        </option>
        <option value="Saudi Arabia">Saudi Arabia
        </option>
        <option value="Senegal">Senegal
        </option>
        <option value="Serbia">Serbia
        </option>
        <option value="Seychelles">Seychelles
        </option>
        <option value="Sierra Leone">Sierra Leone
        </option>
        <option value="Singapore">Singapore
        </option>
        <option value="Sint Maarten (Dutch part)">Sint Maarten (Dutch part)
        </option>
        <option value="Slovakia">Slovakia
        </option>
        <option value="Slovenia">Slovenia
        </option>
        <option value="Solomon Islands">Solomon Islands
        </option>
        <option value="Somalia">Somalia
        </option>
        <option value="South Africa">South Africa
        </option>
        <option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands
        </option>
        <option value="South Korea">South Korea
        </option>
        <option value="South Sudan">South Sudan
        </option>
        <option value="Spain">Spain
        </option>
        <option value="Sri Lanka">Sri Lanka
        </option>
        <option value="Sudan">Sudan
        </option>
        <option value="Suriname">Suriname
        </option>
        <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen
        </option>
        <option value="Swaziland">Swaziland
        </option>
        <option value="Sweden">Sweden
        </option>
        <option value="Switzerland">Switzerland
        </option>
        <option value="Syrian Arab Republic">Syrian Arab Republic
        </option>
        <option value="Taiwan">Taiwan
        </option>
        <option value="Tajikistan">Tajikistan
        </option>
        <option value="Tanzania, United Republic of">Tanzania, United Republic of
        </option>
        <option value="Thailand">Thailand
        </option>
        <option value="Timor-Leste">Timor-Leste
        </option>
        <option value="Togo">Togo
        </option>
        <option value="Tokelau">Tokelau
        </option>
        <option value="Tonga">Tonga
        </option>
        <option value="Trinidad and Tobago">Trinidad and Tobago
        </option>
        <option value="Tunisia">Tunisia
        </option>
        <option value="Turkey">Turkey
        </option>
        <option value="Turkmenistan">Turkmenistan
        </option>
        <option value="Turks and Caicos Islands">Turks and Caicos Islands
        </option>
        <option value="Tuvalu">Tuvalu
        </option>
        <option value="Uganda">Uganda
        </option>
        <option value="Ukraine">Ukraine
        </option>
        <option value="United Arab Emirates">United Arab Emirates
        </option>
        <option value="United Kingdom">United Kingdom
        </option>
        <option value="United States">United States
        </option>
        <option value="United States Minor Outlying Islands">United States Minor Outlying Islands
        </option>
        <option value="Uruguay">Uruguay
        </option>
        <option value="Uzbekistan">Uzbekistan
        </option>
        <option value="Vanuatu">Vanuatu
        </option>
        <option value="Venezuela, Bolivarian Republic of">Venezuela, Bolivarian Republic of
        </option>
        <option value="Viet Nam">Viet Nam
        </option>
        <option value="Virgin Islands, British">Virgin Islands, British
        </option>
        <option value="Virgin Islands, U.S.">Virgin Islands, U.S.
        </option>
        <option value="Wallis and Futuna">Wallis and Futuna
        </option>
        <option value="Western Sahara">Western Sahara
        </option>
        <option value="Yemen">Yemen
        </option>
        <option value="Zambia">Zambia
        </option>
        <option value="Zimbabwe">Zimbabwe
        </option>
    </select>
</div>        <div class="form-error"></div>
    </div>    
    

    <div class="input-wrapper full">
        <textarea aria-label="Your message" name="message" required placeholder="How can we help you? *" maxlength="1000"></textarea>
        <div class="charCnt">1000 characters left</div>
        <div class="form-error"></div>
    </div>

    
<div class="full checkbox-wrapper contact-check-wrapper">    
    <label><input type="checkbox" name="contact_check[]" value="email">
        <span class="contact-check-intro">I would like to receive invitations, insights and thought leadership content from Kroll</span>
    </label>
    
</div>
<input type="hidden" name="submitted" value="true">
<input type="hidden" name="form_url" value="/media-coverage/page/4/page-mediacoverage.php">
<div class="button-submit-wrapper full">
    <button type="submit" class="full button green submit" name="submit" value="submit"><span class="button-text">Submit</span><span class="sending"></span></button>
</div>
<span class="privacy-policy"><a href="/privacy/" class="show-pu" target="_blank">View our privacy policy</a></span>    <input type="hidden" name="unique_id" value="fxoifim">
    <input type="hidden" name="form_id" value="form-1">
    <input type="hidden" name="form_name" value="side-form">
    <input type="hidden" name="msg_success" value="Thank you for contacting us. We will get back to you shortly.">
    <input type="hidden" name="msg_success_title" value="Message Sent">
  </form>
</div>    </div>
</div>

<div id="page" class="site">
            

<div id="top-bar" class="top-bar" style="background-color: var(--color-green); background-image: url(https://www.redscan.com/media/bg-image-tb.png);">
    <div class="close white"><span class="cross"></span></div>
    <div class="text">Experiencing a breach? <strong><a href="https://www.redscan.com/incident-response-enquiries/"  target="_blank">Get emergency incident response assistance</a>.</strong></div>
</div>

        <script>
    //console.log('adding fouc');
    //$('html').addClass('fouc_hidden');	
    var h = document.getElementsByTagName("html");
    h[0].classList.add("fouc_hidden");    
</script>


<header id="header" class="site-header">
    <div class="header-inner">
        <div id="header-left">
            <div id="logo">
                                                            <a href="/"><img src="https://www.redscan.com/wp-content/themes/redscan/img/logo-new-white.svg" width=196 height=59 alt="Redscan Logo" class="lazyload" /></a>                        
                                                </div>
            <nav id="site-navigation" class="main-navigation ">
<div class="main-menu">
    <ul class="menu menu-watch">
                    <li class="mega-selector menu-watch mega-menu" data-mega-menu="11663"><a href="https://www.redscan.com/services/"><span>Services</span></a></li>
                                <li class="mega-selector menu-watch mega-menu" data-mega-menu="11688"><a href="https://www.redscan.com/solutions/"><span>Solutions</span></a></li>
                                <li class="mega-selector menu-watch mega-menu" data-mega-menu="11732"><a href="https://www.redscan.com/company/"><span>Company</span></a></li>
                    </ul>
                        <div class="main-menu__mega menu-watch" data-mega-id="11663">
                        <div class="main-menu__mega-section menu-watch">
                            <ul class="main-menu__mega-links menu-watch">
                                    <li class="menu-watch " data-sublink="11671">
                                                    <span class="a no-link menu-watch arrow-active">
                        
                            <div class="menu-title">
                                <span class="rs-icon-wrapper as-v2"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#as-v2"></use></svg></span>Protect                            </div>
                                                            <div class="menu-description">Offensive security assessment and consultancy services</div>
                            
                                                    </span>
                                            </li>
                                    <li class="menu-watch " data-sublink="11664">
                                                    <span class="a no-link menu-watch">
                        
                            <div class="menu-title">
                                <span class="rs-icon-wrapper mdr"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#mdr"></use></svg></span>Detect                            </div>
                                                            <div class="menu-description">Outcome-focused MDR fuelled by frontline intelligence</div>
                            
                                                    </span>
                                            </li>
                                    <li class="menu-watch " data-sublink="11779">
                                                    <span class="a no-link menu-watch">
                        
                            <div class="menu-title">
                                <span class="rs-icon-wrapper mss"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#mss"></use></svg></span>Respond                            </div>
                                                            <div class="menu-description">Unrivaled response through the entire incident lifecycle</div>
                            
                                                    </span>
                                            </li>
                                </ul>
                <div class="menu-bg-img menu-watch"></div>
            </div>
                            <div class="main-menu__mega-section menu-watch">
                                                 <ul class="main-menu__mega-sublinks menu-watch active" data-sublink-id="11671">
                                                            <div class="mega-title-wrapper menu-watch">
                                                                        <ul class="menu-watch">
                                                            <li class="mega-title menu-watch ">
                                                                                                        Offensive Security                                                                        
                                                                                                </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/penetration-testing/" class="menu-watch">Penetration Testing<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/penetration-testing/web-application-testing/" class="menu-watch">Web Application Testing<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/penetration-testing/cloud-penetration-testing/" class="menu-watch">Cloud Penetration Testing<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/penetration-testing/agile-penetration-testing/" class="menu-watch">Agile Penetration Testing<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/red-team-operations/" class="menu-watch">Red Teaming<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/breach-and-attack-simulation/" class="menu-watch">Breach and Attack Simulation<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/vulnerability-assessment/" class="menu-watch">Vulnerability Assessment<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/ransomware-preparedness-assessment/" class="menu-watch">Ransomware Preparedness<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/scenario-based-testing/" class="menu-watch">Scenario-Based Testing<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                                </ul>
                                                                        <ul class="menu-watch">
                                                            <li class="mega-title menu-watch ">
                                                                                                        Advisory Services                                                                        
                                                                                                </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cyber-policy-review/" class="menu-watch">Cyber Policy Review<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cyber-security-due-diligence/" class="menu-watch">Cyber Due Diligence<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/supply-chain-due-diligence/" class="menu-watch">Supply Chain Due Diligence<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/comply/" class="menu-watch">Compliance Advisory<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/virtual-ciso/" class="menu-watch">Virtual CISO<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/dpo-services/" class="menu-watch">DPO Services<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/dark-web-monitoring/" class="menu-watch">Dark Web Monitoring<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/application-security-services/" class="menu-watch">Application Security<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/threat-modelling/" class="menu-watch">Threat Modelling<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        </ul>
                        </div>
                                                                                        </ul>     
                                                         <ul class="main-menu__mega-sublinks menu-watch" data-sublink-id="11664">
                                                            <div class="mega-title-wrapper menu-watch">
                                                                        <ul class="menu-watch">
                                                            <li class="mega-title menu-watch ">
                                                                                                        <a href="/services/managed-detection-and-response/" class="menu-watch">
                                                                        Managed Detection and Response                                                                        </a>
                                                                        
                                                                                                </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/managed-detection-and-response/" class="menu-watch">Kroll Responder MDR<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/managed-detection-and-response/microsoft/" class="menu-watch">MDR for Microsoft<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/managed-detection-and-response/use-cases/" class="menu-watch">Use Cases<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/managed-detection-and-response/the-redscan-platform/" class="menu-watch">Redscan Platform<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/managed-detection-and-response/mdr-features/" class="menu-watch">Features Table<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/managed-detection-and-response/mdr-vs-mssp/" class="menu-watch">MDR vs MSSP<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        </ul>
                        </div>
                                                                                                <li class="menu-bg-img-right menu-watch" style="background-image: url(https://www.redscan.com/media/mdr-menu@1x.svg);"></li>

                                                            </ul>     
                                                         <ul class="main-menu__mega-sublinks menu-watch" data-sublink-id="11779">
                                                            <div class="mega-title-wrapper menu-watch">
                                                                        <ul class="menu-watch">
                                                            <li class="mega-title menu-watch ">
                                                                                                        Digital Forensics and Incident Response                                                                        
                                                                                                </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cyber-incident-response/" class="menu-watch">Cyber Incident Response<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cyber-incident-response-planning/" class="menu-watch">Incident Response Planning<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/breach-notification/" class="menu-watch">Breach Notification<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cyber-security-digital-forensics/" class="menu-watch">Digital Forensics<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cyber-litigation-support/" class="menu-watch">Litigation Support<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/malware-analysis-and-reverse-engineering/" class="menu-watch">Malware Analysis &<br />Reverse Engineering<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        </ul>
                        </div>
                                                                                                <li class="menu-bg-img-right menu-watch" style="background-image: url(https://www.redscan.com/media/mss@1x.svg);"></li>

                                                            </ul>     
                                                </div>            
                                </div>
                                <div class="main-menu__mega menu-watch" data-mega-id="11688">
                        <div class="main-menu__mega-section menu-watch">
                            <ul class="main-menu__mega-links menu-watch">
                                    <li class="menu-watch two-column" data-sublink="11689">
                                                    <a href="/industries/" class="a menu-watch arrow-active">
                        
                            <div class="menu-title">
                                <span class="rs-icon-wrapper energy"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#energy"></use></svg></span>Industry                            </div>
                            
                                                    </a>
                                            </li>
                                    <li class="menu-watch " data-sublink="11704">
                                                    <a href="/services/comply/" class="a menu-watch">
                        
                            <div class="menu-title">
                                <span class="rs-icon-wrapper compliance-v3"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#compliance-v3"></use></svg></span>Compliance                            </div>
                            
                                                    </a>
                                            </li>
                                    <li class="menu-watch " data-sublink="11712">
                                                    <a href="/services/cloud-security-management-and-monitoring/" class="a menu-watch">
                        
                            <div class="menu-title">
                                <span class="rs-icon-wrapper environment"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#environment"></use></svg></span>Cloud Security                            </div>
                            
                                                    </a>
                                            </li>
                                    <li class="menu-watch " data-sublink="11721">
                                                    <a href="/solutions/challenges/" class="a menu-watch">
                        
                            <div class="menu-title">
                                <span class="rs-icon-wrapper target"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#target"></use></svg></span>Security Challenge                            </div>
                            
                                                    </a>
                                            </li>
                                </ul>
                <div class="menu-bg-img menu-watch"></div>
            </div>
                            <div class="main-menu__mega-section menu-watch">
                                                 <ul class="main-menu__mega-sublinks menu-watch active two-column" data-sublink-id="11689">
                                                    <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/education/" class="menu-watch">Education<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/energy/" class="menu-watch">Energy<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/finance/" class="menu-watch">Finance<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/fintech/" class="menu-watch">Fintech<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/government/" class="menu-watch">Government<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/healthcare/" class="menu-watch">Healthcare<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/legal/" class="menu-watch">Legal<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/manufacturing/" class="menu-watch">Manufacturing<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/media/" class="menu-watch">Media<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/nonprofit/" class="menu-watch">Nonprofit<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/property/" class="menu-watch">Property<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/retail-and-ecommerce/" class="menu-watch">Retail<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/technology/" class="menu-watch">Technology<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/industries/transport/" class="menu-watch">Transport<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                                                            </ul>     
                                                         <ul class="main-menu__mega-sublinks menu-watch" data-sublink-id="11704">
                                                    <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/gdpr/" class="menu-watch">GDPR<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/data-protection-act-2018/" class="menu-watch">DPA 2018<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/pci-dss/" class="menu-watch">PCI DSS<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/iso-27001/" class="menu-watch">ISO 27001<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/nis-directive-and-nis-regulations/" class="menu-watch">NIS Directive<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/swift-customer-security-programme/" class="menu-watch">SWIFT CSP<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/nhs-data-security-and-protection-toolkit/" class="menu-watch">NHS DSP Toolkit<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                                                            </ul>     
                                                         <ul class="main-menu__mega-sublinks menu-watch" data-sublink-id="11712">
                                                    <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cloud-security-management-and-monitoring/hybrid/" class="menu-watch">Hybrid Cloud<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cloud-security-management-and-monitoring/aws/" class="menu-watch">AWS<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cloud-security-management-and-monitoring/azure/" class="menu-watch">Azure<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cloud-security-management-and-monitoring/gcp-security-monitoring/" class="menu-watch">GCP<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cloud-security-management-and-monitoring/office-365/" class="menu-watch">Office 365<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cloud-security-management-and-monitoring/g-suite/" class="menu-watch">G Suite<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cloud-security-management-and-monitoring/hyper-v/" class="menu-watch">Hyper-V<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cloud-security-management-and-monitoring/vmware/" class="menu-watch">VMWare<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                                                            </ul>     
                                                         <ul class="main-menu__mega-sublinks menu-watch" data-sublink-id="11721">
                                                    <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/solutions/mitigating-cyber-security-risk/" class="menu-watch">Mitigating cyber security risk<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/solutions/identifying-and-responding-to-threats/" class="menu-watch">Identifying and responding to threats<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/solutions/testing-cyber-security-readiness/" class="menu-watch">Testing cyber security readiness<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/cloud-security-management-and-monitoring/" class="menu-watch">Managing cloud security<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/solutions/investigating-and-reporting-data-breaches/" class="menu-watch">Investigating and reporting breaches<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/solutions/protecting-against-malware/" class="menu-watch">Protecting against malware<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/solutions/preventing-phishing-bec-attacks/" class="menu-watch">Tackling phishing and BEC attacks<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/solutions/insider-threats-cyber-security/" class="menu-watch">Defending against insider threats<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/services/gdpr/" class="menu-watch">Achieving GDPR compliance<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/solutions/securing-remote-workers/" class="menu-watch">Securing remote workers<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                                                            </ul>     
                                                </div>            
                                </div>
                                <div class="main-menu__mega menu-watch" data-mega-id="11732">
                        <div class="main-menu__mega-section menu-watch">
                            <ul class="main-menu__mega-links menu-watch">
                                    <li class="menu-watch " data-sublink="11733">
                                                    <a href="/company/" class="a menu-watch arrow-active">
                        
                            <div class="menu-title">
                                <span class="rs-icon-wrapper property"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#property"></use></svg></span>About                            </div>
                            
                                                    </a>
                                            </li>
                                    <li class="menu-watch " data-sublink="11740">
                                                    <a href="/resources/" class="a menu-watch">
                        
                            <div class="menu-title">
                                <span class="rs-icon-wrapper news"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#news"></use></svg></span>Resources                            </div>
                            
                                                    </a>
                                            </li>
                                    <li class="menu-watch " data-sublink="11748">
                                                    <a href="/general-enquiries/" class="a menu-watch">
                        
                            <div class="menu-title">
                                <span class="rs-icon-wrapper location"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#location"></use></svg></span>Contact Us                            </div>
                            
                                                    </a>
                                            </li>
                                </ul>
                <div class="menu-bg-img menu-watch"></div>
            </div>
                            <div class="main-menu__mega-section menu-watch">
                                                 <ul class="main-menu__mega-sublinks menu-watch active" data-sublink-id="11733">
                                                    <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/company/" class="menu-watch">Company Overview<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/company/careers/" class="menu-watch">Careers<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/company/awards-and-recognition/" class="menu-watch">Awards<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/company/accreditations-and-memberships/" class="menu-watch">Accreditations<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/company/redscan-labs/" class="menu-watch">Redscan Labs<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                                                            </ul>     
                                                         <ul class="main-menu__mega-sublinks menu-watch" data-sublink-id="11740">
                                                    <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/news/" class="menu-watch">Cyber Security Blog<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/company/case-studies/" class="menu-watch">Case Studies<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/resources/" class="menu-watch">Resource Hub<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/press-releases/" class="menu-watch">Press Releases<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/media-coverage/" class="menu-watch">Media Coverage<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/cyber-security-glossary/" class="menu-watch">Cyber Security Glossary<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                                                            </ul>     
                                                         <ul class="main-menu__mega-sublinks menu-watch" data-sublink-id="11748">
                                                    <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/general-enquiries/" class="menu-watch">General Enquiries<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/incident-response-enquiries/" class="menu-watch">Incident Response Enquiries<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/general-enquiries/customer-support/" class="menu-watch">Customer Support<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/partners/" class="menu-watch">Partner With Us<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                        <li class="menu-watch ">
                                                                    <a href="https://www.redscan.com/media-requests/" class="menu-watch">Media Requests<span class="hover-arrow menu-watch"><span class="rs-icon-wrapper arrow red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></span></a>
                                                            </li>
                            
                                                                                            </ul>     
                                                </div>            
                                </div>
            
    </div>

</nav>        </div>
        <div id="header-right">
            <a href="/general-enquiries/" class="button">Get In Touch <span class="rs-icon-wrapper arrow right"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></a>
        </div>
                    <div id="hamburger" class="mobile-nav">
    <div class="menu-bar" data-toggle="offCanvas">
        <span class="ham"></span>
    </div>				
</div>            </div>
    </header>    	<div id="content" class="site-content">	<div id="primary" class="content-area">
		<main id="main" class="site-main">
			
<div id="post-14014" class="post-14014 post type-post status-publish format-standard has-post-thumbnail hentry category-announcements category-assess category-detect-respond category-news">
	<div class="entry-content">
	
	    <section class="nwgju-wrapper section no-padding ">
        <div id="slider-mcdirka" class="hero-slider slider-type-2 normal">
                        <div class="single-slide"  aria-hidden="true">
                <div class="single-slide-wrapper">
                    <div class="slide-image">
                                                <picture><source srcset="https://www.redscan.com/wp-content/webp-express/webp-images/doc-root/media/circuits-blue-1920x868.jpg.webp" type="image/webp"><img width="1920" height="868" src="https://www.redscan.com/media/circuits-blue-1920x868.jpg" class="desktop no-lazyload webpexpress-processed" alt="Blue data flowing across a circuit board" decoding="async" fetchpriority="high"></picture>                        <picture><source data-srcset="https://www.redscan.com/wp-content/webp-express/webp-images/doc-root/media/circuits-blue-scaled.jpg.webp 2560w, https://www.redscan.com/wp-content/webp-express/webp-images/doc-root/media/circuits-blue-300x158.jpg.webp 300w, https://www.redscan.com/wp-content/webp-express/webp-images/doc-root/media/circuits-blue-1024x540.jpg.webp 1024w, https://www.redscan.com/wp-content/webp-express/webp-images/doc-root/media/circuits-blue-768x405.jpg.webp 768w, https://www.redscan.com/wp-content/webp-express/webp-images/doc-root/media/circuits-blue-1536x810.jpg.webp 1536w, https://www.redscan.com/wp-content/webp-express/webp-images/doc-root/media/circuits-blue-475x250.jpg.webp 475w, https://www.redscan.com/wp-content/webp-express/webp-images/doc-root/media/circuits-blue-150x79.jpg.webp 150w" srcset="https://www.redscan.com/wp-content/webp-express/webp-images/doc-root/media/circuits-blue-scaled.jpg.webp" sizes="(max-width: 375px) 100vw, 375px" type="image/webp"><img width="375" height="198" src="https://www.redscan.com/media/circuits-blue-scaled.jpg" class="mobile lazyload webpexpress-processed" alt="Blue data flowing across a circuit board" decoding="async" srcset="" sizes="(max-width: 375px) 100vw, 375px" data-src="https://www.redscan.com/media/circuits-blue-scaled.jpg" data-srcset="https://www.redscan.com/media/circuits-blue-scaled.jpg 2560w, https://www.redscan.com/media/circuits-blue-300x158.jpg 300w, https://www.redscan.com/media/circuits-blue-1024x540.jpg 1024w, https://www.redscan.com/media/circuits-blue-768x405.jpg 768w, https://www.redscan.com/media/circuits-blue-1536x810.jpg 1536w, https://www.redscan.com/media/circuits-blue-475x250.jpg 475w, https://www.redscan.com/media/circuits-blue-150x79.jpg 150w"></picture>                    </div>
                    <div class="image-overlay"></div>
                                        <div class="slide-content-wrapper">
                        <div class="slide-content-inner">         
                            <div class="slide-content ">
                                                                    <div class="slider-title"><h1>Oops - page not found!</h1></div>
                                              
                                                                                  
                                
                                
                                
                                                            </div>
                        </div>

                        
                                     
                        
                                                            
                        
                    </div>
                                                                
                </div>
            </div>
            
                                        <a href="#top-of-page" aria-label="Scroll Down the Page"><div class="scroll-down"><span class="rs-icon-wrapper arrow-medium down white"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow-medium"></use></svg></span></div></a>
              
        </div>
    </section>

<section class="lqtao-wrapper section ">
        <div class="container">
        <div class="grid">
            <div class="column">
                

<div class="grid header">
    <header class="default-header">
             
                                    <h2 class="xs"></h2>
                         
                    </header>  
</div>



                <div class="inner-text">
                    <p>It looks like nothing was found at this location. Maybe try one of the links below?</p>
<p><a class="button plain with-icon" href="/services/">Services<span class="rs-icon-wrapper arrow right red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></a> <a class="button plain with-icon" href="/solutions/">Solutions<span class="rs-icon-wrapper arrow right red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></a> <a class="button plain with-icon" href="/company/">Company<span class="rs-icon-wrapper arrow right red"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#arrow"></use></svg></span></a></p>
                </div>  
            </div>
        </div>
    </div>
</section>	
	</div>
</div>
		</main>
	</div>
    
    </div><!-- #content -->
    <div class="pu-overlay"></div>
    <div class="page-loader"></div>

    
    <footer class="" id="colophon">
        <div class="inner-content">
            <div class="footer-left">
                <div id="footer-widget-4" class="footer-widget">
                    <div id="nav_menu-3" class="widget widget_nav_menu"><div class="menu-footer-links-container"><ul id="menu-footer-links" class="menu"><li id="menu-item-12385" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12385"><a href="https://www.redscan.com/services/penetration-testing/">Penetration Testing</a></li>
<li id="menu-item-12578" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12578"><a href="https://www.redscan.com/services/managed-detection-and-response/">Managed Detection &#038; Response</a></li>
<li id="menu-item-12388" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12388"><a href="https://www.redscan.com/services/cyber-incident-response/">Incident Response</a></li>
</ul></div></div>                </div>
                <div id="footer-widget-1" class="footer-widget" style="flex-direction: column; align-items: flex-start; justify-content: center;">
                                </div>
            </div>
            <div class="footer-right">
                <div id="footer-widget-2" class="footer-widget">
                    <div id="aws_enhanced_text-4" class="widget widget_aws_enhanced_text">			<div class="textwidget">
<span style="font-weight: 600;">Contact Redscan: <a href="tel:+442039722500">+44 (0)203 972 2500</a></span>
<div style="margin-top: 0.5rem;">London Office: The Shard, 32 London Bridge Street, London, SE1 9SG, UK</div>





</div>
		</div><div id="nav_menu-2" class="widget widget_nav_menu"><div class="menu-footer-menu-container"><ul id="menu-footer-menu" class="menu"><li id="menu-item-5197" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5197"><a href="https://www.redscan.com/privacy/">Privacy Notice</a></li>
<li id="menu-item-5198" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5198"><a href="https://www.redscan.com/legal-notice/">Legal Notice</a></li>
<li id="menu-item-5199" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5199"><a href="https://www.redscan.com/company-policies/">Company Policies</a></li>
</ul></div></div>                </div>
                <div id="footer-widget-3" class="footer-widget">
                    <div id="aws_enhanced_text-3" class="widget widget_aws_enhanced_text">			<div class="textwidget"><ul class="social-icons"><li><a href="https://www.linkedin.com/company/redscan/" target="_blank" class="social-link" rel="noopener noreferrer" aria-label="Linked In"><span class="rs-icon-wrapper linkedin"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#linkedin"></use></svg></span></a></li><li><a href="https://twitter.com/Redscan" target="_blank" class="social-link" rel="noopener noreferrer" aria-label="Twitter"><span class="rs-icon-wrapper twitter"><svg class="icon" preserveAspectRatio="xMinYMin" role="img"><use xlink:href="https://www.redscan.com/wp-content/themes/redscan/img/icons.svg#twitter"></use></svg></span></a></li></ul></div>
		</div>                </div>
            </div>
        </div>
        <div id="copyright">
            <div id="aws_enhanced_text-2" class="widget widget_aws_enhanced_text">			<div class="textwidget">© Redscan (a trading name of Redscan Cyber Security Limited) 2023. All rights reserved.<br />Company Number - 09786838. ICO Registration Number - ZA184902.</div>
		</div>        </div>
    </footer>

</div><!-- #page -->

<script src="https://www.redscan.com/wp-content/themes/redscan/js/jquery.min.js?ver=1585746202" id="jquery-js"></script>
<script src="https://www.redscan.com/wp-content/themes/redscan/js/site.min.js?ver=1687253045" id="redscan-init-js-js"></script>
<script id="redscan-init-js-js-after">
/* <![CDATA[ */
var postID = 14014
/* ]]> */
</script>
</body>
</html>
